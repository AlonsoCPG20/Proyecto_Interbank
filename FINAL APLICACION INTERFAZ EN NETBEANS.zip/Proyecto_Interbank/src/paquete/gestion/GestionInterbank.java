/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.gestion;

import javax.swing.JOptionPane;
import paquete.clases.Pedido;

/**
 *
 * @author Alonso
 */
public class GestionInterbank {
    private Pedido[] arreglo;
    private int cont;

    public GestionInterbank() 
    {
        arreglo = new Pedido[50];
        cont=0;
    }

    public Pedido[] getArreglo() {
        return arreglo;
    }

    public void setArreglo(Pedido[] arreglo) {
        this.arreglo = arreglo;
    }

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    
    
    
    public void IngresarPedido(Pedido a)
    {
        try
        {
            arreglo[cont]=a;
            cont++;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "No hay espacio");
        }
    }
    
    public void Eliminar(int codigo)
    {
        for(int i=0;i<cont;i++)
        {
            if(arreglo[i].getCodProducto()==codigo)
            {
                for(int j=i;j<cont-1;j++)
                {
                    arreglo[j]=arreglo[j+1];
                }
                arreglo[cont-1]=null;
                cont--;
            }
        }
    }
    
    public void IngresarManual(int pos,Pedido a)
    {
        if(cont<arreglo.length)
        {
            if(pos<cont)
            {
                for(int i=cont-1;i>=pos;i--)
                {
                    arreglo[i+1]=arreglo[i];
                }
                arreglo[pos]=a;
                cont++;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Tiene que ingresar en posicon menor al amximo ingresado");
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "No hay espacio");
        }
    }

}
