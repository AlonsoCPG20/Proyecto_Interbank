/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package paquete.clases;

/**
 *
 * @author jean_
 */
public Hardware2(int COD_PROD, String TIPO_PROD, String NOM_PROD) {
        super(COD_PROD, TIPO_PROD, NOM_PROD);

}
