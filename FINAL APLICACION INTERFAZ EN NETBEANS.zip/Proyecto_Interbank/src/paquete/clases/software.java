/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

/**
 *
 * @author Alonso
 */

public class software extends Pedido{

    public software(int CODempleado, int codCliente, int codProducto, int unidades, String nombreProducto, String NombreApellido) {
        super(CODempleado, codCliente, codProducto, unidades, nombreProducto, NombreApellido);
    } 
}
