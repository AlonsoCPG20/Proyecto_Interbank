/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.clases;

/**
 *
 * @author Alonso
 */
public class Pedido {
    protected int CODempleado, codCliente, codProducto, unidades;
    protected String nombreProducto, NombreApellido;

    public Pedido(int CODempleado, int codCliente, int codProducto, int unidades, String nombreProducto, String NombreApellido) {
        this.CODempleado = CODempleado;
        this.codCliente = codCliente;
        this.codProducto = codProducto;
        this.unidades = unidades;
        this.nombreProducto = nombreProducto;
        this.NombreApellido = NombreApellido;
    }

    public int getCODempleado() {
        return CODempleado;
    }

    public void setCODempleado(int CODempleado) {
        this.CODempleado = CODempleado;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getCodProducto() {
        return codProducto;
    }

    public void setCodProducto(int codProducto) {
        this.codProducto = codProducto;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getNombreApellido() {
        return NombreApellido;
    }

    public void setNombreApellido(String NombreApellido) {
        this.NombreApellido = NombreApellido;
    }
    
    

    
    
    
    
    
}
