/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package paquete.clases;

/**
 *
 * @author jean_
 */
public class Producto {

    protected int COD_PROD, NRO_SERIE;
    protected String TIPO_PROD, NOM_PROD;
    }

    public Producto(int COD_PROD, String TIPO_PROD, String NOM_PROD) {
        this.COD_PROD = COD_PROD;
        this.TIPO_PROD = TIPO_PROD;
        this.NOM_PROD = NOM_PROD;
    }

    public int getCOD_PROD() {
        return COD_PROD;
    }

    public void setCOD_PROD(int COD_PROD) {
        this.COD_PROD = COD_PROD;
    }

    public int getNRO_SERIE() {
        return NRO_SERIE;
    }

    public void setNRO_SERIE(int NRO_SERIE) {
        this.NRO_SERIE = NRO_SERIE;
    }

    public String getTIPO_PROD() {
        return TIPO_PROD;
    }

    public void setTIPO_PROD(String TIPO_PROD) {
        this.TIPO_PROD = TIPO_PROD;
    }

    public String getNOM_PROD() {
        return NOM_PROD;
    }

    public void setNOM_PROD(String NOM_PROD) {
        this.NOM_PROD = NOM_PROD;
    }

}
